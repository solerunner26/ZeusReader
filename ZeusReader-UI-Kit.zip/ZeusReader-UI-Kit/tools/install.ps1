param([string]$ProjectPath = "")
# ZeusReader UI Kit - one-click installer (Windows PowerShell 5.1+)
# Installs the UI/UX skills for Antigravity, adds the Stormlight skills to your repo,
# then opens Antigravity so you can type /stormlight-fix.

$ErrorActionPreference = 'Continue'
$KitDir  = Split-Path -Parent $PSScriptRoot
$Payload = Join-Path $KitDir 'payload'

function Say($msg, $color = 'Cyan') { Write-Host ""; Write-Host "==> $msg" -ForegroundColor $color }
function Ok($msg)   { Write-Host "    [OK] $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "    [!]  $msg" -ForegroundColor Yellow }
function Has($cmd)  { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function IsProject($p) {
    return ($p -and (Test-Path $p) -and ((Test-Path (Join-Path $p 'settings.gradle.kts')) -or (Test-Path (Join-Path $p 'settings.gradle'))))
}
function FileHas($path, $text) {
    if (-not (Test-Path $path)) { return $false }
    return [bool](Select-String -Path $path -SimpleMatch $text -Quiet)
}

Write-Host ""
Write-Host "  ZeusReader UI Kit - Stormlight installer" -ForegroundColor Magenta
Write-Host "  ----------------------------------------" -ForegroundColor Magenta

# 1. Find the Gradle project (settings.gradle.kts) and the repo root (.git)
Say "Finding your ZeusReader project"
function FindProject($start) {
    if (-not $start -or -not (Test-Path $start)) { return $null }
    if (IsProject $start) { return (Resolve-Path $start).Path }
    $hit = Get-ChildItem -Path $start -Recurse -Depth 2 -File -Include 'settings.gradle.kts','settings.gradle' -ErrorAction SilentlyContinue |
           Where-Object { $_.FullName -notmatch '\\(build|node_modules|\.gradle|payload)\\' } | Select-Object -First 1
    if ($hit) { return $hit.DirectoryName }
    return $null
}
$GradleRoot = $null
$candidates = @($ProjectPath, $KitDir, (Split-Path -Parent $KitDir), (Get-Location).Path,
    "$HOME\OneDrive\Desktop\E-Reader", "$env:OneDrive\Desktop\E-Reader", "$HOME\Desktop\E-Reader")
foreach ($c in $candidates) { $r = FindProject $c; if ($r) { $GradleRoot = $r; break } }
if (-not $GradleRoot) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Select your E-Reader / ZeusReader project folder'
    if ($dlg.ShowDialog() -eq 'OK') { $GradleRoot = FindProject $dlg.SelectedPath }
}
if (-not $GradleRoot) { Warn "Could not find settings.gradle.kts. Nothing was changed."; exit 1 }

# Repo root = folder with .git (skills, design and AGENTS.md go here, and agy starts here)
$Root = $null
if (Has 'git') {
    $top = git -C $GradleRoot rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -eq 0 -and $top) { $Root = (Resolve-Path $top).Path }
}
if (-not $Root) {
    $d = Get-Item $GradleRoot
    while ($d) { if (Test-Path (Join-Path $d.FullName '.git')) { $Root = $d.FullName; break }; $d = $d.Parent }
}
if (-not $Root) { $Root = $GradleRoot }
$IsGit = (Has 'git') -and (Test-Path (Join-Path $Root '.git'))
Ok "Repo root:      $Root"
Ok "Android/Gradle: $GradleRoot"
Set-Location $Root

# 1b. Clean up files that an older kit version put in the wrong (Gradle) folder
if ($GradleRoot -ne $Root) {
    foreach ($s in @('stormlight-design','stormlight-fix')) {
        $old = Join-Path $GradleRoot ".agents\skills\$s"
        if (Test-Path $old) { Remove-Item -Recurse -Force $old; Ok "Removed old copy: $old" }
    }
    foreach ($dir in @('.agents\skills','.agents')) {
        $p = Join-Path $GradleRoot $dir
        if ((Test-Path $p) -and -not (Get-ChildItem -Force $p)) { Remove-Item -Force $p }
    }
    $oldAgents = Join-Path $GradleRoot 'AGENTS.md'
    if (Test-Path $oldAgents) {
        $txt = (Get-Content -Raw $oldAgents).Trim()
        if ($txt -match '^## UI rule\s*- All UI work must load the stormlight-design skill' -and ($txt -split "`n").Count -le 2) {
            Remove-Item -Force $oldAgents; Ok "Removed old copy: $oldAgents"
        }
    }
}

# 2. Check tools
Say "Checking tools"
if (-not (Has 'agy')) { Warn "Antigravity CLI (agy) not found. Install it, open a NEW terminal, run this kit again."; exit 1 }
Ok "agy found"
if (-not (Has 'npx')) {
    Warn "Node.js (npx) is missing. It is needed for the Superpowers skills."
    $ans = Read-Host "    Install Node.js LTS now with winget? (y/n)"
    if ($ans -eq 'y' -and (Has 'winget')) {
        winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
        $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
    }
}
if (Has 'npx') { Ok "npx found" } else { Warn "npx still missing - Superpowers will be skipped." }

# 3. Safety branch + keep kit files out of git
if ($IsGit) {
    Say "Creating a safety branch"
    if (git status --porcelain) { Warn "You have uncommitted changes. They stay as they are, but consider committing them first." }
    git show-ref --verify --quiet refs/heads/ui/stormlight
    if ($LASTEXITCODE -eq 0) { git switch ui/stormlight 2>$null | Out-Null } else { git switch -c ui/stormlight 2>$null | Out-Null }
    Ok "Branch: $(git branch --show-current) (your main branch is untouched)"

    $ex = Join-Path $Root '.git\info\exclude'
    $kitRel = $KitDir.Substring([Math]::Min($Root.Length, $KitDir.Length)).TrimStart('\').Replace('\','/')
    if ($KitDir -eq $Root) { $lines = @('/INSTALL-UI-KIT.cmd','/README.txt','/payload/','/tools/install.ps1') }
    elseif ($KitDir.StartsWith($Root)) { $lines = @("/$kitRel/") }
    else { $lines = @() }
    foreach ($l in $lines) { if (-not (FileHas $ex $l)) { Add-Content $ex $l } }
    if ($lines.Count) { Ok "Kit files hidden from git" }
}

# 4. Add the Stormlight skills + design files at the repo root
Say "Adding Stormlight skills to $Root\.agents\skills"
$skillsDst = Join-Path $Root '.agents\skills'
New-Item -ItemType Directory -Force -Path $skillsDst | Out-Null
Copy-Item -Recurse -Force (Join-Path $Payload '.agents\skills\*') $skillsDst
$gradleRel = $GradleRoot.Substring($Root.Length).TrimStart('\').Replace('\','/')
if (-not $gradleRel) { $gradleRel = '.' }
foreach ($f in Get-ChildItem -Recurse -File $skillsDst -Filter SKILL.md | Where-Object { $_.FullName -match 'stormlight-' }) {
    (Get-Content -Raw $f.FullName).Replace('{{GRADLE_DIR}}', $gradleRel) | Set-Content -Encoding UTF8 $f.FullName
}
Ok "stormlight-design and stormlight-fix installed (Gradle folder: $gradleRel)"

$designDst = Join-Path $Root 'design'
$srcDesign = Join-Path $Payload 'design'
Get-ChildItem -Recurse -File $srcDesign | ForEach-Object {
    $rel = $_.FullName.Substring($srcDesign.Length).TrimStart('\')
    $dst = Join-Path $designDst $rel
    if (-not (Test-Path $dst)) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item $_.FullName $dst
    }
}
Ok "design\ folder checked (existing files were kept)"

# 5. Point the project rules at the skill
$rule = 'All UI work must load the stormlight-design skill first (.agents/skills/stormlight-design). It overrides generic design skills.'
foreach ($f in @('AGENTS.md','GEMINI.md')) {
    $p = Join-Path $Root $f
    if ($f -eq 'AGENTS.md' -or (Test-Path $p)) {
        if (-not (FileHas $p 'stormlight-design')) { Add-Content -Path $p -Value "`r`n## UI rule`r`n- $rule" }
        Ok "$f updated"
    }
}

# 6. Helper skills
Say "Installing helper skills"
if (Has 'npx') {
    if ((Test-Path (Join-Path $Root '.agent')) -or (Test-Path (Join-Path $Root '.agents\skills\ui-ux-pro-max'))) {
        Warn "Superpowers looks already installed - skipped (to avoid overwriting your files)."
    } else {
        npx -y agy-superpowers@latest init
        if ($LASTEXITCODE -eq 0) { Ok "Superpowers (/mobile-uiux-promax, /ui-ux-pro-max)" } else { Warn "Superpowers install failed" }
    }
}
$list = (agy plugin list 2>$null) -join "`n"
if ($list -match 'agent-skills') { Ok "Addy Osmani agent-skills (already installed)" } else {
    agy plugin install https://github.com/addyosmani/agent-skills.git
    if ($LASTEXITCODE -eq 0) { Ok "Addy Osmani agent-skills" } else { Warn "agent-skills install failed" }
}
if ($list -match 'android') { Ok "Android skills (already installed)" } else {
    agy plugin install https://github.com/android/skills
    if ($LASTEXITCODE -eq 0) { Ok "Google Android skills" } else { Warn "Android skills not installed here - /stormlight-fix Phase 1 will find the official one." }
}

Say "Installed plugins"
agy plugin list

# 7. Launch from the repo root
Say "All set! Antigravity is starting in $Root" 'Green'
Write-Host ""
Write-Host "    Type this and press Enter:   /stormlight-fix" -ForegroundColor Yellow
Write-Host "    After each phase it stops and shows you screenshots. Reply 'go' to continue." -ForegroundColor Yellow
Write-Host ""
agy
