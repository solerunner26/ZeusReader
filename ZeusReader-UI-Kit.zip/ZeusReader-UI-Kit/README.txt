ZeusReader UI Kit (Stormlight)
==============================

1. Unzip this folder INSIDE your ZeusReader project folder
   (C:\Users\jaldi\OneDrive\Desktop\E-Reader). Anywhere else also works: it searches for the project.
2. Double-click INSTALL-UI-KIT.cmd
3. When Antigravity opens, type:  /stormlight-fix
   It works phase by phase and stops after each one. Reply "go" to continue.

What it does
- Creates a git branch "ui/stormlight" so your main branch stays safe
- Adds .agents\skills\stormlight-design  (your design rules, auto-loaded every session)
- Adds .agents\skills\stormlight-fix     (the one-time "fix everything" workflow)
- Copies design\DESIGN.md + design\screens if they're missing (never overwrites)
- Adds a UI rule line to AGENTS.md
- Installs helper skills: Superpowers, Addy Osmani agent-skills, Google Android skills

Later: whenever you ask Antigravity for any UI change, it loads stormlight-design by itself.
To undo everything: git switch main  (then delete the ui/stormlight branch).
